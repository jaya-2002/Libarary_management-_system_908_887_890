<?php include('header.php'); ?>
<?php include('navbar.php'); ?>
    <div class="container">
		<div class="margin-top">
			<div class="row">
					<?php include('head.php'); ?>
					
					</div>The Central library spreads over to ground plus six floors with an area of 7770 sq.m. It is centrally air-conditioned, well-protected with fire alarm and CCTV surveillance. It has specialized collections of Books, Journals & other resources in Sciences, Engineering and Technology, Biotechnology, Humanities, Social Sciences and Management ranging from printed books, e-books, back volumes, CDs\ DVDs, video cassettes to audio cassettes. The Central Library subscribes to national and international journals in print and e-Journals. The library has a video conferencing facility and NPTEL video courses. Central Library is using LIBSYS ver7 software for Library Management and Information System Purpose and it has WEB-OPAC (Online Public Access Catalogue facility) to consult the Library Information. Also implemented the Radio Frequency Identification Technology (RFID) and self issue and return kiosks.
					</br></br></br>
				
			
				<div class="span2">
				<h4></h4>
			
				</div>
				<div class="span10">
				
				
					
					
				
				
				</div>
			
			</div>
		</div>
    </div>
<?php include('footer.php') ?>